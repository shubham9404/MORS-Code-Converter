//
//  ViewController.swift
//  MorsCodeConverter
//
//  Created by Shubham Shinde on 06/02/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var enterText: UITextField!
    
    var one = ". _ _ _ _"
    var two = ". . _ _ _"
    var three = ". . . _ _"
    var four = ". . . . _"
    var five = ". . . . ."
    var six = "_ . . . ."
    var seven = "_ _ . . ."
    var eight = "_ _ _ . ."
    var nine = "_ _ _ _ ."
    var zero = "_ _ _ _ _"
    
    var a = ". _"
    var b = "_ . . ."
    var c = "_ . _ ."
    var d = "_ . ."
    var e = "."
    var f = ". . _ ."
    var g = "_ _ ."
    var h = ". . . ."
    var i = ". ."
    var j = ". _ _ _"
    var k = "_ . _"
    var l = ". _ . ."
    var m = "_ _"
    var n = "_ ."
    var o = "_ _ _"
    var p = ". _ _ ."
    var q = "_ _ . _"
    var r = ". _ ."
    var s = ". . ."
    var t = "_"
    var u = ". . _"
    var v = ". . . _"
    var w = ". _ _ _"
    var x = "_ . . _"
    var y = "_ . _ _"
    var z = "_ _ . ."
    
    @IBAction func convert(_ sender: UIButton) {
        if enterText.text! == "0"
        {
            outPut.text = zero
        }
        
        if enterText.text! == "1"
        {
            outPut.text = one
        }
        
        if enterText.text! == "2"
        {
            outPut.text = two
        }
        
        if enterText.text! == "3"
        {
            outPut.text = three
        }
        
        if enterText.text! == "4"
        {
            outPut.text = four
        }
        
        if enterText.text! == "5"
        {
            outPut.text = five
        }
        
        if enterText.text! == "6"
        {
            outPut.text = six
        }
        
        if enterText.text! == "7"
        {
            outPut.text = seven
        }
        
        if enterText.text! == "8"
        {
            outPut.text = eight
        }
        
        if enterText.text! == "9"
        {
            outPut.text = nine
        }
        
        if enterText.text! == "a"
        {
            outPut.text = a
        }
        
        if enterText.text! == "b"
        {
            outPut.text = b
        }
        
        if enterText.text! == "c"
        {
            outPut.text = c
        }
        
        if enterText.text! == "d"
        {
            outPut.text = d
        }
        
        if enterText.text! == "e"
        {
            outPut.text = e
        }
        
        if enterText.text! == "f"
        {
            outPut.text = f
        }
        
        if enterText.text! == "g"
        {
            outPut.text = g
        }
        
        if enterText.text! == "h"
        {
            outPut.text = h
        }
        
        if enterText.text! == "i"
        {
            outPut.text = i
        }
        
        if enterText.text! == "j"
        {
            outPut.text = j
        }
        
        if enterText.text! == "k"
        {
            outPut.text = k
        }
        
        if enterText.text! == "l"
        {
            outPut.text = l
        }
        
        if enterText.text! == "m"
        {
            outPut.text = m
        }
        
        if enterText.text! == "n"
        {
            outPut.text = n
        }
        
        if enterText.text! == "o"
        {
            outPut.text = o
        }
        
        if enterText.text! == "p"
        {
            outPut.text = p
        }
        
        if enterText.text! == "q"
        {
            outPut.text = q
        }
        
        if enterText.text! == "r"
        {
            outPut.text = r
        }
        
        if enterText.text! == "s"
        {
            outPut.text = s
        }
        
        if enterText.text! == "t"
        {
            outPut.text = t
        }
        
        if enterText.text! == "u"
        {
            outPut.text = s
        }
        
        if enterText.text! == "v"
        {
            outPut.text = s
        }
        
        if enterText.text! == "w"
        {
            outPut.text = w
        }
        
        if enterText.text! == "x"
        {
            outPut.text = x
        }
        
        if enterText.text! == "y"
        {
            outPut.text = y
        }
        
        if enterText.text! == "z"
        {
            outPut.text = z
        }
        
        if enterText.text! == "A"
        {
            outPut.text = a
        }
        
        if enterText.text! == "B"
        {
            outPut.text = b
        }
        
        if enterText.text! == "C"
        {
            outPut.text = c
        }
        
        if enterText.text! == "D"
        {
            outPut.text = d
        }
        
        if enterText.text! == "E"
        {
            outPut.text = e
        }
        
        if enterText.text! == "F"
        {
            outPut.text = f
        }
        
        if enterText.text! == "G"
        {
            outPut.text = g
        }
        
        if enterText.text! == "H"
        {
            outPut.text = h
        }
        
        if enterText.text! == "I"
        {
            outPut.text = i
        }
        
        if enterText.text! == "J"
        {
            outPut.text = j
        }
        
        if enterText.text! == "K"
        {
            outPut.text = k
        }
        
        if enterText.text! == "L"
        {
            outPut.text = l
        }
        
        if enterText.text! == "M"
        {
            outPut.text = m
        }
        
        if enterText.text! == "N"
        {
            outPut.text = n
        }
        
        if enterText.text! == "O"
        {
            outPut.text = o
        }
        
        if enterText.text! == "P"
        {
            outPut.text = p
        }
        
        if enterText.text! == "Q"
        {
            outPut.text = q
        }
        
        if enterText.text! == "R"
        {
            outPut.text = r
        }
        
        if enterText.text! == "S"
        {
            outPut.text = s
        }
        
        if enterText.text! == "T"
        {
            outPut.text = t
        }
        
        if enterText.text! == "U"
        {
            outPut.text = s
        }
        
        if enterText.text! == "V"
        {
            outPut.text = s
        }
        
        if enterText.text! == "W"
        {
            outPut.text = w
        }
        
        if enterText.text! == "X"
        {
            outPut.text = x
        }
        
        if enterText.text! == "Y"
        {
            outPut.text = y
        }
        
        if enterText.text! == "Z"
        {
            outPut.text = z
        }
        
        
        if enterText.text! == ".____"
        {
            outPut.text = "1"
        }
        
        if enterText.text! == "..___"
        {
            outPut.text = "2"
        }
        
        if enterText.text! == "...__"
        {
            outPut.text = "3"
        }
        
        if enterText.text! == "...._"
        {
            outPut.text = "4"
        }
        
        if enterText.text! == "....."
        {
            outPut.text = "5"
        }
        
        if enterText.text! == "_...."
        {
            outPut.text = "6"
        }
        
        if enterText.text! == "__..."
        {
            outPut.text = "7"
        }
        
        if enterText.text! == "___.."
        {
            outPut.text = "8"
        }
        
        if enterText.text! == "____."
        {
            outPut.text = "9"
        }
        
        if enterText.text! == "_____"
        {
            outPut.text = "0"
        }
        
        if enterText.text! == "._"
        {
            outPut.text = "a"
        }
        
        if enterText.text! == "_..."
        {
            outPut.text = "b"
        }
        
        if enterText.text! == "_._."
        {
            outPut.text = "c"
        }
        
        if enterText.text! == "_.."
        {
            outPut.text = "d"
        }
        
        if enterText.text! == "."
        {
            outPut.text = "e"
        }
        
        if enterText.text! == ".._."
        {
            outPut.text = "f"
        }
        
        if enterText.text! == "__."
        {
            outPut.text = "g"
        }
        
        if enterText.text! == "...."
        {
            outPut.text = "h"
        }
        
        if enterText.text! == ".."
        {
            outPut.text = "i"
        }
        
        if enterText.text! == ".___"
        {
            outPut.text = "j"
        }
        
        if enterText.text! == "_._"
        {
            outPut.text = "k"
        }
        
        if enterText.text! == "._.."
        {
            outPut.text = "l"
        }
        
        if enterText.text! == "__"
        {
            outPut.text = "m"
        }
        
        if enterText.text! == "_."
        {
            outPut.text = "n"
        }
        
        if enterText.text! == "___"
        {
            outPut.text = "o"
        }
        
        if enterText.text! == ".__."
        {
            outPut.text = "p"
        }
        
        if enterText.text! == "__._"
        {
            outPut.text = "q"
        }
        
        if enterText.text! == "._."
        {
            outPut.text = "r"
        }
        
        if enterText.text! == "..."
        {
            outPut.text = "s"
        }
        
        if enterText.text! == "_"
        {
            outPut.text = "t"
        }
        
       if enterText.text! == ".._"
       {
           outPut.text = "u"
       }
        
        if enterText.text! == "..._"
        {
            outPut.text = "v"
        }
        
        if enterText.text! == ".___"
        {
            outPut.text = "w"
        }
        
        if enterText.text! == "_.._"
        {
            outPut.text = "x"
        }
        
        if enterText.text! == "_.__"
        {
            outPut.text = "y"
        }
        
        if enterText.text! == "__.."
        {
            outPut.text = "z"
        }
        
        if enterText.text! == ""
        {
            outPut.text = ""
        }
    }
    
    @IBOutlet weak var outPut: UILabel!
}

